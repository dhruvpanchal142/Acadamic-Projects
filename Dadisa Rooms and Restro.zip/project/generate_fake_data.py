# generate_fake_data.py
import argparse
import uuid
import random
from faker import Faker
import pandas as pd
from datetime import datetime, timedelta
from filelock import FileLock

fake = Faker("en_IN")
FAKER_SEED = 42
Faker.seed(FAKER_SEED)
random.seed(FAKER_SEED)

ROOM_TYPES = ["Deluxe", "Super Deluxe", "Suite", "Standard"]
PURPOSES = ["Business", "Family Tour", "Personal", "Other"]
ARRIVAL_MODES = ["Flight", "Train", "Bus", "Travels", "Own", "Other"]
ID_PROOFS = ["Aadhaar Card", "Passport", "Driving License", "Voter ID", "PAN Card"]

# Utility to create ID numbers consistent with Indian patterns (approx)
def gen_id_number(id_type):
    if id_type == "Aadhaar Card":
        # 12 digit numeric, not starting with 0
        return "".join(str(random.randint(0,9)) for _ in range(12))
    if id_type == "Passport":
        # 1 letter + 7 digits
        return random.choice("ABCDEFGHIJKLMNOPQRSTUVWXYZ") + "".join(str(random.randint(0,9)) for _ in range(7))
    if id_type == "Driving License":
        # Two letters (state) + 2 digits year + 11 alnum (approx)
        return "".join(random.choices("ABCDEFGHIJKLMNOPQRSTUVWXYZ", k=2)) + "".join(str(random.randint(0,9)) for _ in range(2)) + "".join(random.choices("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ", k=8))
    if id_type == "Voter ID":
        return "".join(random.choices("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", k=10))
    if id_type == "PAN Card":
        # PAN format: 5 letters + 4 digits + 1 letter
        return "".join(random.choices("ABCDEFGHIJKLMNOPQRSTUVWXYZ", k=5)) + "".join(str(random.randint(0,9)) for _ in range(4)) + random.choice("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
    return "".join(random.choices("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", k=10))


def gen_mobile():
    # Indian mobile numbers start with 6-9 and 10 digits
    return str(random.choice([6,7,8,9])) + "".join(str(random.randint(0,9)) for _ in range(9))

def gen_email(name, idx):
    username = "".join(ch for ch in name.lower() if ch.isalnum()) + str(idx)
    domain = random.choice(["gmail.com","yahoo.com","outlook.com","hotmail.com","rediffmail.com","indianmail.in"])
    return f"{username}@{domain}"

def gen_checkin_checkout():
    # pick a checkin within last 90 days to next 30 days
    start = datetime.now() - timedelta(days=90)
    checkin = start + timedelta(days=random.randint(0,120), hours=random.randint(0,23), minutes=random.randint(0,59))
    # stay length 1 to 10 days
    nights = random.randint(1,7)
    checkout = checkin + timedelta(days=nights, hours=random.randint(0,5))
    return checkin, checkout

def build_row(idx):
    name = fake.name()
    city = fake.city()
    state = fake.state()
    mobile = gen_mobile()
    id_type = random.choice(ID_PROOFS)
    id_num = gen_id_number(id_type)
    room = random.choice(ROOM_TYPES)
    checkin, checkout = gen_checkin_checkout()
    guests = random.randint(1,4)
    purpose = random.choice(PURPOSES)
    arrival = random.choice(ARRIVAL_MODES)
    email = gen_email(name, idx)
    booking_id = str(uuid.uuid4())
    created_at = datetime.now().isoformat()
    return {
        "BookingID": booking_id,
        "CustomerName": name,
        "City": city,
        "State": state,
        "Mobile": mobile,
        "Email": email,
        "IDProofType": id_type,
        "IDNumber": id_num,
        "RoomType": room,
        "CheckInDateTime": checkin.isoformat(sep=" "),
        "CheckOutDateTime": checkout.isoformat(sep=" "),
        "NumGuests": guests,
        "Purpose": purpose,
        "ArrivalMode": arrival,
        "CreatedAt": created_at
    }

def generate_to_excel(count, out_file):
    rows = [build_row(i) for i in range(1, count+1)]
    df = pd.DataFrame(rows)
    # If file exists and has same columns, append; else create new
    lock_path = out_file + ".lock"
    with FileLock(lock_path, timeout=10):
        try:
            existing = pd.read_excel(out_file, engine="openpyxl")
            # Ensure columns match; if not, raise
            required_cols = list(df.columns)
            if list(existing.columns) != required_cols:
                raise RuntimeError("Existing Excel has different columns/headers. Please remove or rename it.")
            combined = pd.concat([existing, df], ignore_index=True)
            combined.to_excel(out_file, index=False, engine="openpyxl")
            print(f"Appended {len(df)} rows to {out_file}. Total rows now: {len(combined)}")
        except FileNotFoundError:
            df.to_excel(out_file, index=False, engine="openpyxl")
            print(f"Created {out_file} with {len(df)} rows.")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--count", type=int, default=200, help="Number of fake unique rows to generate (100-500 recommended)")
    ap.add_argument("--out", type=str, default="dadisa_bookings.xlsx", help="Output Excel file")
    args = ap.parse_args()
    if args.count < 1 or args.count > 5000:
        raise SystemExit("Count should be between 1 and 5000 (but 100-500 is recommended).")
    generate_to_excel(args.count, args.out)
