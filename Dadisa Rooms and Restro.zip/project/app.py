from flask import Flask, render_template, request, redirect, url_for, flash
import pandas as pd
from filelock import FileLock
import uuid
import re
import os
from datetime import datetime

app = Flask(__name__)
app.secret_key = "super_secret_key"

DATA_FILE = "dadisa_bookings.xlsx"
LOCK_FILE = DATA_FILE + ".lock"

# Validation regex
MOBILE_RE = re.compile(r"^[6-9]\d{9}$")
EMAIL_RE = re.compile(r"^[\w\.-]+@[\w\.-]+\.\w+$")

@app.route("/")
def index():
    return redirect(url_for("booking_form"))

@app.route("/form", methods=["GET", "POST"])
def booking_form():
    if request.method == "POST":
        name = request.form["name"].strip()
        city = request.form["city"].strip()
        state = request.form["state"].strip()
        mobile = request.form["mobile"].strip()
        email = request.form["email"].strip()
        id_type = request.form["id_type"]
        id_number = request.form["id_number"].strip()
        room_type = request.form["room_type"]
        check_in = request.form["check_in"]
        check_out = request.form["check_out"]
        guests = request.form["guests"]
        purpose = request.form["purpose"]
        arrival = request.form["arrival"]

        # Validation
        if not MOBILE_RE.match(mobile):
            flash("❌ Invalid mobile number. Must be 10 digits starting with 6–9.")
            return redirect(url_for("booking_form"))

        if not EMAIL_RE.match(email):
            flash("❌ Invalid email address.")
            return redirect(url_for("booking_form"))

        booking_id = str(uuid.uuid4())[:8]

        new_data = {
            "BookingID": booking_id,
            "CustomerName": name,
            "City": city,
            "State": state,
            "Mobile": mobile,
            "Email": email,
            "IDProofType": id_type,
            "IDNumber": id_number,
            "RoomType": room_type,
            "CheckIn": check_in,
            "CheckOut": check_out,
            "Guests": guests,
            "Purpose": purpose,
            "ArrivalMode": arrival
        }

        # Append to Excel safely
        lock = FileLock(LOCK_FILE)
        with lock:
            if os.path.exists(DATA_FILE):
                df = pd.read_excel(DATA_FILE)
                df = pd.concat([df, pd.DataFrame([new_data])], ignore_index=True)
            else:
                df = pd.DataFrame([new_data])

            df.to_excel(DATA_FILE, index=False)

        flash("✅ Booking added successfully!")
        return redirect(url_for("booking_form"))

    return render_template("form.html")

if __name__ == "__main__":
    app.run(debug=True)
